/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isoverflow.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:44:43 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:44:43 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libft.h"

int	ft_isoverflow(long long nbr)
{
	long long	max;
	long long	min;

	max = 2147483647;
	min = -2147483648;
	if (nbr > max)
		return (1);
	if (nbr < min)
		return (-1);
	else
		return (0);
}
