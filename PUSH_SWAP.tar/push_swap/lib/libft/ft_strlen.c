/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:20 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:20 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlen(const char *src)
{
	const char	*tmp;

	tmp = src;
	if (!src)
		return (0);
	while (*tmp++)
		;
	return ((size_t)(tmp - src - 1));
}
