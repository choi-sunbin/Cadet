/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:29 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:30 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(const char *src, char (*f)(unsigned int, char))
{
	char			*ret;
	unsigned int	ix;
	unsigned int	size;

	if (!src || !f)
		return (NULL);
	ix = 0;
	size = ft_strlen(src);
	ret = (char *)malloc(sizeof(char) * (size + 1));
	if (!ret)
		return (NULL);
	while (src[ix])
	{
		ret[ix] = (*f)(ix, src[ix]);
		ix++;
	}
	return (ret);
}
