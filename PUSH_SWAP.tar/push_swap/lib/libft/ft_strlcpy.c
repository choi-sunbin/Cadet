/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:16 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:16 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	size_t	src_l;
	size_t	ix;

	if (!dst || !src || !dstsize)
		return (0);
	ix = 0;
	src_l = ft_strlen(src);
	while (src[ix] && ix + 1 < dstsize && ix < src_l)
	{
		dst[ix] = src[ix];
		ix++;
	}
	if (dstsize > 0)
		dst[ix] = '\0';
	return (src_l);
}
