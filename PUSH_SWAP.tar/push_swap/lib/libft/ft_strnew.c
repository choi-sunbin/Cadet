/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:40 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:41 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnew(char *str, size_t strlen)
{
	char	*ret;
	size_t	ix;

	ix = 0;
	ret = (char *)malloc(sizeof(char) * (strlen + 1));
	if (!ret)
		return (NULL);
	while (ix < strlen)
	{
		ret[ix] = str[ix];
		ix++;
	}
	str[ix] = '\0';
	return (ret);
}
