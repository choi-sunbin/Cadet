/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:47 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:47 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *src, int c)
{
	unsigned int	src_l;

	if (!src)
		return (NULL);
	src_l = (unsigned int)ft_strlen(src);
	while (src_l != 0 && src[src_l] != (char)c)
		src_l--;
	if (src[src_l] == (char)c)
		return ((char *)src + src_l);
	return (NULL);
}
