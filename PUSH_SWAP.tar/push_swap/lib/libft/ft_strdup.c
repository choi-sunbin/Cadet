/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:46:51 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:46:52 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s)
{
	char	*ret;
	int		len;

	if (!s)
		return (NULL);
	len = (int)ft_strlen(s);
	ret = (char *)malloc(len + 1);
	ft_memcpy(ret, s, (len + 1));
	return (ret);
}
