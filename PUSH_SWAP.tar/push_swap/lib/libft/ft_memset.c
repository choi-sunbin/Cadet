/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:46:10 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:46:12 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *dst, int c, size_t n)
{
	unsigned char	*temp;
	unsigned char	value;

	if (!dst)
		return (NULL);
	temp = dst;
	value = c;
	while (n--)
	{
		*temp++ = value;
	}
	return ((void *)dst);
}
