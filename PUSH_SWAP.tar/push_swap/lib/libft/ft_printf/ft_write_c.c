/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_write_c.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:43:35 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:43:36 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./ft_printf.h"

static int	ft_define_c_target(t_info *info, va_list *ap)
{
	if (info->type == '%')
		return ('%');
	else
		return ((char)va_arg(*ap, int));
}

static int	ft_define_c_len(t_info *info)
{
	if (info->width > 1)
		return (info->width);
	else
		return (1);
}

int	ft_print_c(t_info *info, va_list *ap)
{
	char	target;
	int		pad_len;
	int		ret;

	pad_len = ft_define_c_len(info) - 1;
	target = ft_define_c_target(info, ap);
	ret = 0;
	if (info->left == 1)
		ret += ft_putchar(target);
	ret += ft_write_padding(info, pad_len);
	if (info->left == 0)
		ret += ft_putchar(target);
	return (ret);
}
