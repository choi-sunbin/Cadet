/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:08 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:08 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char	*set_memory(const char *s1, const char *s2,
		unsigned int *s1_l, unsigned int *s2_l)
{
	char	*ret;

	*s1_l = ft_strlen(s1);
	*s2_l = ft_strlen(s2);
	ret = (char *)malloc(sizeof(char) * (*s1_l + *s2_l + 1));
	if (!ret)
		return (NULL);
	return (ret);
}

char	*ft_strjoin(const char *s1, const char *s2)
{
	char			*ret;
	unsigned int	s1_l;
	unsigned int	s2_l;

	if (!s1 && !s2)
		return (NULL);
	else if (!s1 || !s2)
	{
		if (!(s1))
			return (ft_strdup(s2));
		else
			return (ft_strdup(s1));
	}
	ret = set_memory(s1, s2, &s1_l, &s2_l);
	if (!ret)
		return (NULL);
	while (*s1)
		*(ret++) = *(s1++);
	while (*s2)
		*(ret++) = *(s2++);
	*ret = '\0';
	return (ret);
}
