/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:47:44 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:47:44 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, size_t n)
{
	size_t	len;

	len = ft_strlen(little);
	if (!little || !n || n < len)
		return (0);
	while (*big && len <= n)
	{
		if (!ft_strncmp(big, little, n))
			return ((char *)big);
		big++;
	}
	return (0);
}
