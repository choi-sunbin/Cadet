/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_ss.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:09:24 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:09:26 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_ss(t_bucket *bucket, int checker_flag)
{
	ps_inst_sa(bucket, 1, checker_flag);
	ps_inst_sb(bucket, 1, checker_flag);
	if (!checker_flag)
		write(1, "ss\n", 3);
	bucket->count--;
}
