/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_pb.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:08:35 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:08:36 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_pb(t_bucket *bucket, int checker_flag)
{
	t_dlst	*node;

	if (bucket->a->size == 0)
		return ;
	node = ps_dlstpop_front(bucket->a);
	ps_dlstadd_front(bucket->b, node);
	if (!checker_flag)
		write(1, "pb\n", 3);
	bucket->count++;
}
