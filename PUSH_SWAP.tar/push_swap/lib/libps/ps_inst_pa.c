/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_pa.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:08:30 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:08:32 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_pa(t_bucket *bucket, int checker_flag)
{
	t_dlst	*node;

	if (bucket->b->size == 0)
		return ;
	node = ps_dlstpop_front(bucket->b);
	ps_dlstadd_front(bucket->a, node);
	if (!checker_flag)
		write(1, "pa\n", 3);
	bucket->count++;
}
