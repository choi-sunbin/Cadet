/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_dlstswap.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:05:14 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:05:16 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_dlstswap_next(t_dlst *node)
{
	t_dlst	*ptr_next;

	ptr_next = node->next;
	node->before->next = ptr_next;
}
