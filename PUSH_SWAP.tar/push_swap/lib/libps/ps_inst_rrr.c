/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_rrr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:09:09 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:09:10 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_rrr(t_bucket *bucket, int checker_flag)
{
	ps_inst_rra(bucket, 1, checker_flag);
	ps_inst_rrb(bucket, 1, checker_flag);
	if (!checker_flag)
		write(1, "rrr\n", 3);
	bucket->count--;
}
