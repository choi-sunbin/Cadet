/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_rr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:08:56 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:08:57 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_rr(t_bucket *bucket, int checker_flag)
{
	ps_inst_ra(bucket, 1, checker_flag);
	ps_inst_rb(bucket, 1, checker_flag);
	if (!checker_flag)
		write(1, "rr\n", 3);
	bucket->count--;
}
