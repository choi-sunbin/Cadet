/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_dlstfind_idx.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:04:12 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:04:38 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

int	ps_dlstfind_idx(t_stack *stack, int rank, int *rra_flag)
{
	int		ix;
	t_dlst	*nptr;

	if (stack->size == 0 || rank < 0 || !stack->top)
		return (-1);
	ix = 0;
	*rra_flag = 0;
	nptr = stack->top;
	while (ix < stack->size)
	{
		if (*rra_flag == 0 && ix > (stack->size / 2) - (stack->size % 2))
			*rra_flag = 1;
		if (nptr->rank == rank)
			return (ix);
		nptr = nptr->next;
		ix++;
	}
	return (-1);
}
