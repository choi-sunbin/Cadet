/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_dlstclear.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 21:33:01 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 21:33:01 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

int	ps_dlstclear(t_stack *stack)
{
	int	ix;
	int	limit;

	ix = 0;
	limit = stack->size;
	while (ix < limit)
	{
		ps_dlstdel_front(stack);
		ix++;
	}
	return (EXIT_SUCCESS);
}
