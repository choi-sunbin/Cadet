/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_dlstdel_front.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:04:02 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:04:05 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

int	ps_dlstdel_front(t_stack *stack)
{
	t_dlst	*ptr;

	if (stack->size == 0)
		return (0);
	ptr = stack->top->next;
	free(stack->top);
	if (stack->size == 1)
		stack->top = NULL;
	else
		stack->top = ptr;
	stack->size--;
	return (1);
}
