/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_dlstadd_front.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 21:32:56 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 21:32:57 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

int	ps_dlstadd_front(t_stack *stack, t_dlst *new_top)
{
	t_dlst	*old_top;
	t_dlst	*old_bottom;

	old_top = stack->top;
	old_bottom = stack->bottom;
	if (!new_top)
		return (EXIT_FAILURE);
	if (stack->size == 0)
	{
		stack->top = new_top;
		stack->bottom = new_top;
		new_top->next = NULL;
		new_top->before = NULL;
		stack->size++;
	}
	else
	{
		new_top->next = old_top;
		new_top->before = old_bottom;
		old_top->before = new_top;
		old_bottom->next = new_top;
		stack->top = new_top;
		stack->size++;
	}
	return (EXIT_SUCCESS);
}
