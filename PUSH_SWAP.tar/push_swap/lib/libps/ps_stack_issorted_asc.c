/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_stack_issorted_asc.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:09:31 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:09:31 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

int	ps_stack_issorted_asc(t_stack *stack)
{
	int		ix;
	int		flag;
	t_dlst	*nptr;

	ix = 0;
	flag = 1;
	nptr = stack->top;
	while (ix < stack->size - 1)
	{
		if (nptr->value > nptr->next->value)
		{
			flag = 0;
			break ;
		}
		nptr = nptr->next;
		ix++;
	}
	return (flag);
}
