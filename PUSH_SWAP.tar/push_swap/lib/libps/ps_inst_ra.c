/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_inst_ra.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 22:08:42 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 22:08:43 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libps.h"

void	ps_inst_ra(t_bucket *bucket, int rr_flag, int checker_flag)
{
	unsigned int	ix;
	t_dlst			*old_top;

	if (bucket->a->size == 0)
		return ;
	ix = 0;
	old_top = bucket->a->top;
	bucket->a->top = old_top->next;
	bucket->a->bottom = old_top;
	if (!checker_flag && !rr_flag)
		write(1, "ra\n", 3);
	bucket->count++;
}
