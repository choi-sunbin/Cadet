/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bubblesort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 21:31:15 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 21:31:18 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static void	fn_swap(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

int	fn_bubblesort(int *a, int size)
{
	int	i;
	int	j;

	i = 0;
	while (i < (size - 1))
	{
		j = 0;
		while (j < (size - 1))
		{
			if (a[j] > a[j + 1])
				fn_swap(&a[j], &a[j + 1]);
			j++;
		}
		i++;
	}
	return (0);
}

int	fn_is_sorted(int *arr, int size)
{
	int	i;
	int	j;
	int	sorted;

	sorted = 1;
	i = 0;
	while (i < (size - 1))
	{
		j = 0;
		while (j < (size - 1))
		{
			if (arr[j] > arr[j + 1])
			{
				sorted = 0;
				break ;
			}
			j++;
		}
		i++;
	}
	return (sorted);
}
