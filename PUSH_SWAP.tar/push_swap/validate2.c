/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/04 21:32:24 by sunbchoi          #+#    #+#             */
/*   Updated: 2021/10/04 21:32:25 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	fn_set_argv(int argc, char **argv, t_bucket *data)
{
	int		ix;
	int		jx;
	int		zx;
	char	**tmp;

	zx = 0;
	ix = 1;
	data->input_arr_str = (char **)ft_calloc(sizeof(char *), 10000);
	if (argc <= 1)
		return (ft_strerr("Error\n"));
	while (ix < argc)
	{
		jx = 0;
		tmp = ft_split(argv[ix], ' ');
		while (tmp[jx])
			data->input_arr_str[zx++] = tmp[jx++];
		free(tmp);
		ix++;
	}
	data->arg_size = zx;
	return (0);
}
