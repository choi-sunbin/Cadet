#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void *))
{
	t_list	*now;
	t_list	*nxt;

	now = *lst;
	while (now)
	{
		nxt = now->next;
		ft_lstdelone(now, del);
		now = nxt;
	}
	*lst = 0;
}
