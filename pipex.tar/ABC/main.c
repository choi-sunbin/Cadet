#include "pipex.h"

void	parent_process(pid_t pid, int status, int *pipefd, char **argv)
{
	int	result;

	check_child_fin(pid, status);
	close(pipefd[1]);
	redirect_out(argv[4]);
	result = dup2(pipefd[0], 0);
	if (result == -1)
		exit(1);
	execution(argv[3]);
	close(pipefd[0]);
}

void	child_process(int *pipefd, char **argv)
{
	int	result;

	close(pipefd[0]);
	redirect_in(argv[1]);
	result = dup2(pipefd[1], 1);
	if (result == -1)
		exit(1);
	execution(argv[2]);
	close(pipefd[1]);
}

int	main(int argc, char *argv[])
{
	pid_t	pid;
	int		status;
	int		pipefd[2];

	status = 0;
	if (argc != 5)
	{
		write(1, "please just 4 argument!\n", 24);
		exit(1);
	}
	pipe(pipefd);
	pid = fork();
	if (pid > 0)
		parent_process(pid, status, pipefd, argv);
	else if (pid == 0)
		child_process(pipefd, argv);
	else
		exit(1);
	return (0);
}
