#ifndef PIPEX_H
# define PIPEX_H

# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <sys/wait.h>
# include <stdio.h>
# include <string.h>
# include "libft/libft.h"

typedef struct s_cmd
{
	char	*cmd[5];
	char	**cmd_options;
}	t_cmd;

void	redirect_in(char *file);
void	redirect_out(char *file);
void	connect_pipe(int pipefd[2], int io);
void	set_cmd(char *cmd, t_cmd *input_cmd);
void	execution(char *cmd);
void	check_child_fin(pid_t pid, int status);
void	child_process(int *pipefd, char **argv);
void	parent_process(pid_t pid, int status, int *pipefd, char **argv);

#endif