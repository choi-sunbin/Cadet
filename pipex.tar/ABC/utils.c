#include "pipex.h"

void	redirect_in(char *file)
{
	int	fd;
	int	result;

	fd = open(file, O_RDONLY);
	if (fd < 0)
	{
		perror(file);
		exit(1);
	}
	result = dup2(fd, 0);
	if (result == -1)
		exit(1);
	close(fd);
}

void	redirect_out(char *file)
{
	int	fd;
	int	result;

	fd = open(file, O_RDWR | O_CREAT | O_TRUNC, 0644);
	if (fd < 0)
	{
		perror(file);
		exit(1);
	}
	result = dup2(fd, 1);
	if (result == -1)
		exit(1);
	close(fd);
}

void	check_child_fin(pid_t pid, int status)
{
	waitpid(pid, &status, 0);
	if (WIFEXITED(status) == 0)
		exit(1);
}

void	set_cmd(char *cmd, t_cmd *input_cmd)
{
	char	**cmd_head;

	cmd_head = ft_split(cmd, ' ');
	input_cmd->cmd[0] = ft_strjoin("/bin/", cmd_head[0]);
	input_cmd->cmd[1] = ft_strjoin("/usr/local/bin/", cmd_head[0]);
	input_cmd->cmd[2] = ft_strjoin("/usr/bin/", cmd_head[0]);
	input_cmd->cmd[3] = ft_strjoin("/usr/sbin/", cmd_head[0]);
	input_cmd->cmd[4] = ft_strjoin("/sbin/", cmd_head[0]);
	input_cmd->cmd_options = cmd_head;
}

void	execution(char *cmd)
{
	int		i;
	t_cmd	input_cmd;

	i = 0;
	set_cmd(cmd, &input_cmd);
	while (i < 5)
		execve(input_cmd.cmd[i++], input_cmd.cmd_options, NULL);
	perror(input_cmd.cmd_options[0]);
}
