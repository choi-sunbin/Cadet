#include "pipex.h"

void	redirect_in(char *file)
{
	int	fd;
	int	result;

	fd = open(file, O_RDONLY);
	if (fd < 0)
	{
		perror(file);
		exit(1);
	}
	result = dup2(fd, 0);
	if (result == -1)
		exit(1);
	close(fd);
}

void	redirect_out(char *file)
{
	int	fd;
	int	result;

	fd = open(file, O_RDWR | O_CREAT | O_TRUNC, 0644); //읽고 쓰기, 없으면 만들기, 내용 지우기
	//S_IRWXU : (00700) - owner에 대한 읽기, 쓰기, 실행권한 모두 설정 
	//S_IRUSR : (00400) - owner에 대한 읽기 권한 
	//S_IWUSR : (00200) - owner에 대한 쓰기 권한 
	//S_IXUSR : (00100) - owner에 대한 실행 권한 
	//S_IRWXG : (00070) - group에 대한 읽기, 쓰기, 실행권한 모두 설정 
	//S_IRGRP : (00040) - Group에 대한 읽기 권한 
	//S_IWGRP : (00020) - Group에 대한 쓰기 권한 
	//S_IXGRP : (00010) - Group에 대한 실행 권한 
	//S_IRWXO : (00007) - Other에 대한 읽기, 쓰기, 실행권한 모두 설정 
	//S_IROTH : (00004) - Other에 대한 읽기 권한 
	//S_IWOTH : (00002) - Other에 대한 쓰기 권한 
	//S_IXOTH : (00001) - Other에 대한 실행 권한
	if (fd < 0)
	{
		perror(file);
		exit(1);
	}
	result = dup2(fd, 1);
	if (result == -1)
		exit(1);
	close(fd);
}

void	check_child_fin(pid_t pid, int status)
{
	waitpid(pid, &status, 0); //waitpid() : 자식 프로세스의 종료를 기다린다.
	if (WIFEXITED(status) == 0) //자식 프로세스의 상태를 확인하는 메크로
		exit(1);
}

void	set_cmd(char *cmd, t_cmd *input_cmd)
{
	char	**cmd_head;

	cmd_head = ft_split(cmd, ' ');
	input_cmd->cmd[0] = ft_strjoin("/bin/", cmd_head[0]);
	input_cmd->cmd[1] = ft_strjoin("/usr/local/bin/", cmd_head[0]);
	input_cmd->cmd[2] = ft_strjoin("/usr/bin/", cmd_head[0]);
	input_cmd->cmd[3] = ft_strjoin("/usr/sbin/", cmd_head[0]);
	input_cmd->cmd[4] = ft_strjoin("/sbin/", cmd_head[0]);
	input_cmd->cmd_options = cmd_head;
}

void	execution(char *cmd)
{
	int		i;
	t_cmd	input_cmd;

	i = 0;
	set_cmd(cmd, &input_cmd);
	while (i < 5)
		execve(input_cmd.cmd[i++], input_cmd.cmd_options, NULL);
	perror(input_cmd.cmd_options[0]);
}
