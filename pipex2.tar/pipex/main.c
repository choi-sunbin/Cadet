#include "pipex.h"

void	parent_process(pid_t pid, int status, int *pipefd, char **argv)
{
	int	result;

	check_child_fin(pid, status);
	close(pipefd[WRITE]);
	redirect_out(argv[4]); //1, 명1, 명2, 2 -> 2
	result = dup2(pipefd[READ], 0);
	if (result == -1)
		exit(1);
	execution(argv[3]);
	close(pipefd[0]);
}

void	child_process(int *pipefd, char **argv)
{
	int	result;

	close(pipefd[READ]);
	redirect_in(argv[1]);
	result = dup2(pipefd[WRITE], 1);
	if (result == -1)
		exit(1);
	execution(argv[2]);
	close(pipefd[WRITE]);
}

int	main(int argc, char *argv[])
{
	pid_t	pid;
	int		status;
	int		pipefd[2];

	status = 0;
	if (argc != 5)
	{
		write(1, "please just 4 argument!\n", 24);
		exit(1);
	}
	pipe(pipefd);// 성공0 실패1
	// IPC (Inter Process Communication)이라 부른다. 
	// IPC를 수행하기 위해선 데이터를 주고 받기 위한 특정 공간이 요구된다. 
	// 하지만 프로세스들은 메모리 상에 각각 독립된 공간을 할당받아 위치하고, 
	// 이들은 서로 공유될 수 없기 때문에 특별한 방식 없이는 IPC 수행에 어려움이 있다.
	// 커널을 통해 데이터 교환
	pid = fork();//자식프로세스 생성
	if (pid > 0) //자식의 pid 0, 자신 기본, 실패 -1
		parent_process(pid, status, pipefd, argv);
	else if (pid == 0)
		child_process(pipefd, argv);
	else
		exit(1);
	return (0);
}
