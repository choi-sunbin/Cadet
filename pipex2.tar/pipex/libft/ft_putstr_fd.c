#include "libft.h"

void	ft_putstr_fd(char *s, int fd)
{
	if (s == 0 || fd < 0)
		return ((void)0);
	while (*s != '\0')
	{
		write(fd, s, 1);
		s++;
	}
}
