#include "libft.h"

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t	nd_len;

	if (*needle == '\0')
		return ((char *)haystack);
	nd_len = ft_strlen(needle);
	while (*haystack != '\0' && len >= nd_len)
	{
		if (*haystack == *needle && ft_strncmp(haystack, needle, nd_len) == 0)
			return ((char *)haystack);
		haystack++;
		len--;
	}
	return (0);
}
